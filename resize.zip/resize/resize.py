import cv2
import glob
import os
 
# 画像リサイズをする関数
def resize(path):
    img = cv2.imread(path, 1)        # カラー画像の読み込み
    #h, w, ch = img.shape[:3]         # 画像のサイズを取得（グレースケール画像は[:2]
    #hr = int(h * 2)                  # 縦方向のサイズを計算
    #wr = int(w * 2)                  # 横方向のサイズを計算
    img = cv2.resize(img, (64, 64))  # 画像をリサイズする
    return img
 
# 指定されたディレクトリ内のファイル情報を取得する関数
def bundle_resize(dir,out):
    path_list = glob.glob(dir + '\*.jpg')       # 指定されたディレクトリ内の全てのファイルを取得
    print(path_list)
    name_list = []                          # ファイル名の空リストを定義
    ext_list = []                           # 拡張子の空リストを定義
 
    # ファイルのフルパスからファイル名と拡張子を抽出
    for i in path_list:
        file = os.path.basename(i)          # 拡張子ありファイル名を取得
        name, ext = os.path.splitext(file)  # 拡張子なしファイル名と拡張子を取得
        name_list.append(name)              # 拡張子なしファイル名をリスト化
        ext_list.append(ext)                # 拡張子をリスト化
 
        out_path = os.path.join(*[out, name + '_resize' + ext]) # 保存パスを作成
 
        img = resize(i)                     # リサイズ関数を実行
        cv2.imwrite(out_path, img)          # リサイズ後の画像を保存
    return
 
# ファイルを探してリサイズする関数を実行
bundle_resize('kotsubu','1')
bundle_resize('kyokukotsubu','2')
bundle_resize('niowa','3')
bundle_resize('toromame','4')
bundle_resize('soy','5')
