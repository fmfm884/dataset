import glob
import os

files = glob.glob("*.jpg")
for i, old_name in enumerate(files):
    # ファイル名の決定
    #new_name = "{d}.jpg".format(i + 1)
    new_name = str(i+1) + "_mammy.jpg"
    # ファイル名の変更
    os.rename(old_name, new_name)

